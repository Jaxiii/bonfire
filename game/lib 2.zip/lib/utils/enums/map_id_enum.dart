enum MapBiomeId { none, biome1, biome2 }
